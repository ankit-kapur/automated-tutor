
package tutorapp;
import java.io.*;

public class Main
{
	static int a[]={10,12,3,7,6};
	static FileOutputStream fos;
//	static FileInputStream fis;
        static File correctAnswersFile;
	public static void main(String args[]) throws Exception
	{
 		fos=new FileOutputStream("sort.txt");
		correctAnswersFile = new File("sort.txt");
                
		sort();
		disp();
                TutorJFrame tf= new TutorJFrame(correctAnswersFile);
                tf.setVisible(true);
        }
	public static void sort() throws Exception
	{
		int flag=0;
		for(int i=0;i<a.length;i++)
		{
			fWrite("pass"+(i+1));
			for(int j=0;j<a.length-i-1;j++)
			{
				flag=0;
				fWrite("Compare");
				if(a[j]>a[j+1])
				{
					fWrite("Swap");
					int t=a[j];
					a[j]=a[j+1];
					a[j+1]=t;
					flag=1;
				}
			}
			if(flag==0)
				break;
		}
	}
	public static void disp()
	{
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}
	public static void fWrite(String s) throws Exception
	{
		for(int i=0;i<s.length();i++)
		{
			fos.write(s.charAt(i));
		}
		fos.write(' ');
	}
}
